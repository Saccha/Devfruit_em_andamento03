from app import app
import os

if __name__=='main':
    app.run()

